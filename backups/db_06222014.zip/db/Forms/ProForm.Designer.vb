﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnModPro = New System.Windows.Forms.Button()
        Me.chkBoxRecovery = New System.Windows.Forms.CheckBox()
        Me.chkBoxContact = New System.Windows.Forms.CheckBox()
        Me.grpBoxPro = New System.Windows.Forms.GroupBox()
        Me.lblPro10 = New System.Windows.Forms.Label()
        Me.lblPro8 = New System.Windows.Forms.Label()
        Me.lblPro2 = New System.Windows.Forms.Label()
        Me.lblPro9 = New System.Windows.Forms.Label()
        Me.lblProSurname = New System.Windows.Forms.Label()
        Me.lblPro3 = New System.Windows.Forms.Label()
        Me.lblProName = New System.Windows.Forms.Label()
        Me.lblPro0 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.picBoxPro = New System.Windows.Forms.PictureBox()
        Me.grpBoxPasswd = New System.Windows.Forms.GroupBox()
        Me.lblPro7 = New System.Windows.Forms.Label()
        Me.lblPro6 = New System.Windows.Forms.Label()
        Me.lblAwnser = New System.Windows.Forms.Label()
        Me.lblQuestion = New System.Windows.Forms.Label()
        Me.grpBoxContact = New System.Windows.Forms.GroupBox()
        Me.lblPro4 = New System.Windows.Forms.Label()
        Me.lblPro5 = New System.Windows.Forms.Label()
        Me.lblPro1 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grpBoxPro.SuspendLayout()
        CType(Me.picBoxPro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpBoxPasswd.SuspendLayout()
        Me.grpBoxContact.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnModPro
        '
        Me.btnModPro.Location = New System.Drawing.Point(18, 270)
        Me.btnModPro.Name = "btnModPro"
        Me.btnModPro.Size = New System.Drawing.Size(138, 31)
        Me.btnModPro.TabIndex = 19
        Me.btnModPro.Text = "text"
        Me.btnModPro.UseVisualStyleBackColor = True
        Me.btnModPro.Visible = False
        '
        'chkBoxRecovery
        '
        Me.chkBoxRecovery.AutoSize = True
        Me.chkBoxRecovery.Location = New System.Drawing.Point(476, 273)
        Me.chkBoxRecovery.Name = "chkBoxRecovery"
        Me.chkBoxRecovery.Size = New System.Drawing.Size(43, 17)
        Me.chkBoxRecovery.TabIndex = 18
        Me.chkBoxRecovery.Text = "text"
        Me.chkBoxRecovery.UseVisualStyleBackColor = True
        Me.chkBoxRecovery.Visible = False
        '
        'chkBoxContact
        '
        Me.chkBoxContact.AutoSize = True
        Me.chkBoxContact.Location = New System.Drawing.Point(322, 273)
        Me.chkBoxContact.Name = "chkBoxContact"
        Me.chkBoxContact.Size = New System.Drawing.Size(43, 17)
        Me.chkBoxContact.TabIndex = 17
        Me.chkBoxContact.Text = "text"
        Me.chkBoxContact.UseVisualStyleBackColor = True
        Me.chkBoxContact.Visible = False
        '
        'grpBoxPro
        '
        Me.grpBoxPro.Controls.Add(Me.lblPro10)
        Me.grpBoxPro.Controls.Add(Me.lblPro8)
        Me.grpBoxPro.Controls.Add(Me.lblPro2)
        Me.grpBoxPro.Controls.Add(Me.lblPro9)
        Me.grpBoxPro.Controls.Add(Me.lblProSurname)
        Me.grpBoxPro.Controls.Add(Me.lblPro3)
        Me.grpBoxPro.Controls.Add(Me.lblProName)
        Me.grpBoxPro.Controls.Add(Me.lblPro0)
        Me.grpBoxPro.Controls.Add(Me.Label17)
        Me.grpBoxPro.Controls.Add(Me.picBoxPro)
        Me.grpBoxPro.Controls.Add(Me.grpBoxPasswd)
        Me.grpBoxPro.Controls.Add(Me.grpBoxContact)
        Me.grpBoxPro.Controls.Add(Me.Label16)
        Me.grpBoxPro.Controls.Add(Me.Label15)
        Me.grpBoxPro.Controls.Add(Me.Label12)
        Me.grpBoxPro.Controls.Add(Me.Label11)
        Me.grpBoxPro.Controls.Add(Me.Label9)
        Me.grpBoxPro.Controls.Add(Me.Label8)
        Me.grpBoxPro.Controls.Add(Me.Label6)
        Me.grpBoxPro.Location = New System.Drawing.Point(12, 12)
        Me.grpBoxPro.Name = "grpBoxPro"
        Me.grpBoxPro.Size = New System.Drawing.Size(652, 255)
        Me.grpBoxPro.TabIndex = 16
        Me.grpBoxPro.TabStop = False
        Me.grpBoxPro.Text = "text"
        Me.grpBoxPro.Visible = False
        '
        'lblPro10
        '
        Me.lblPro10.AutoSize = True
        Me.lblPro10.Location = New System.Drawing.Point(405, 60)
        Me.lblPro10.Name = "lblPro10"
        Me.lblPro10.Size = New System.Drawing.Size(56, 13)
        Me.lblPro10.TabIndex = 23
        Me.lblPro10.Text = "Joined on:"
        '
        'lblPro8
        '
        Me.lblPro8.AutoSize = True
        Me.lblPro8.Location = New System.Drawing.Point(418, 92)
        Me.lblPro8.Name = "lblPro8"
        Me.lblPro8.Size = New System.Drawing.Size(69, 13)
        Me.lblPro8.TabIndex = 22
        Me.lblPro8.Text = "Date of Birth:"
        '
        'lblPro2
        '
        Me.lblPro2.AutoSize = True
        Me.lblPro2.Location = New System.Drawing.Point(234, 92)
        Me.lblPro2.Name = "lblPro2"
        Me.lblPro2.Size = New System.Drawing.Size(41, 13)
        Me.lblPro2.TabIndex = 21
        Me.lblPro2.Text = "Mobile:"
        '
        'lblPro9
        '
        Me.lblPro9.AutoSize = True
        Me.lblPro9.Location = New System.Drawing.Point(231, 28)
        Me.lblPro9.Name = "lblPro9"
        Me.lblPro9.Size = New System.Drawing.Size(38, 13)
        Me.lblPro9.TabIndex = 20
        Me.lblPro9.Text = "E-mail:"
        '
        'lblProSurname
        '
        Me.lblProSurname.AutoSize = True
        Me.lblProSurname.Location = New System.Drawing.Point(245, 60)
        Me.lblProSurname.Name = "lblProSurname"
        Me.lblProSurname.Size = New System.Drawing.Size(52, 13)
        Me.lblProSurname.TabIndex = 19
        Me.lblProSurname.Text = "Surname:"
        '
        'lblPro3
        '
        Me.lblPro3.AutoSize = True
        Me.lblPro3.Location = New System.Drawing.Point(52, 92)
        Me.lblPro3.Name = "lblPro3"
        Me.lblPro3.Size = New System.Drawing.Size(81, 13)
        Me.lblPro3.TabIndex = 18
        Me.lblPro3.Text = "Phone Number:"
        '
        'lblProName
        '
        Me.lblProName.AutoSize = True
        Me.lblProName.Location = New System.Drawing.Point(50, 60)
        Me.lblProName.Name = "lblProName"
        Me.lblProName.Size = New System.Drawing.Size(38, 13)
        Me.lblProName.TabIndex = 17
        Me.lblProName.Text = "Name:"
        '
        'lblPro0
        '
        Me.lblPro0.AutoSize = True
        Me.lblPro0.Location = New System.Drawing.Point(58, 28)
        Me.lblPro0.Name = "lblPro0"
        Me.lblPro0.Size = New System.Drawing.Size(46, 13)
        Me.lblPro0.TabIndex = 16
        Me.lblPro0.Text = "User ID:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(343, 60)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(24, 13)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "text"
        '
        'picBoxPro
        '
        Me.picBoxPro.Image = Global.db.My.Resources.Resources.profile
        Me.picBoxPro.Location = New System.Drawing.Point(526, 19)
        Me.picBoxPro.Name = "picBoxPro"
        Me.picBoxPro.Size = New System.Drawing.Size(90, 90)
        Me.picBoxPro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBoxPro.TabIndex = 14
        Me.picBoxPro.TabStop = False
        '
        'grpBoxPasswd
        '
        Me.grpBoxPasswd.Controls.Add(Me.lblPro7)
        Me.grpBoxPasswd.Controls.Add(Me.lblPro6)
        Me.grpBoxPasswd.Controls.Add(Me.lblAwnser)
        Me.grpBoxPasswd.Controls.Add(Me.lblQuestion)
        Me.grpBoxPasswd.Location = New System.Drawing.Point(314, 134)
        Me.grpBoxPasswd.Name = "grpBoxPasswd"
        Me.grpBoxPasswd.Size = New System.Drawing.Size(332, 107)
        Me.grpBoxPasswd.TabIndex = 13
        Me.grpBoxPasswd.TabStop = False
        Me.grpBoxPasswd.Text = "text"
        Me.grpBoxPasswd.Visible = False
        '
        'lblPro7
        '
        Me.lblPro7.AutoSize = True
        Me.lblPro7.Location = New System.Drawing.Point(123, 65)
        Me.lblPro7.Name = "lblPro7"
        Me.lblPro7.Size = New System.Drawing.Size(79, 13)
        Me.lblPro7.TabIndex = 13
        Me.lblPro7.Text = "Secret Awnser:"
        '
        'lblPro6
        '
        Me.lblPro6.AutoEllipsis = True
        Me.lblPro6.AutoSize = True
        Me.lblPro6.Location = New System.Drawing.Point(98, 22)
        Me.lblPro6.MaximumSize = New System.Drawing.Size(225, 0)
        Me.lblPro6.Name = "lblPro6"
        Me.lblPro6.Size = New System.Drawing.Size(86, 13)
        Me.lblPro6.TabIndex = 12
        Me.lblPro6.Text = "Secret Question:"
        '
        'lblAwnser
        '
        Me.lblAwnser.AutoSize = True
        Me.lblAwnser.Location = New System.Drawing.Point(6, 65)
        Me.lblAwnser.Name = "lblAwnser"
        Me.lblAwnser.Size = New System.Drawing.Size(24, 13)
        Me.lblAwnser.TabIndex = 11
        Me.lblAwnser.Text = "text"
        '
        'lblQuestion
        '
        Me.lblQuestion.AutoSize = True
        Me.lblQuestion.Location = New System.Drawing.Point(6, 22)
        Me.lblQuestion.Name = "lblQuestion"
        Me.lblQuestion.Size = New System.Drawing.Size(24, 13)
        Me.lblQuestion.TabIndex = 10
        Me.lblQuestion.Text = "text"
        '
        'grpBoxContact
        '
        Me.grpBoxContact.Controls.Add(Me.lblPro4)
        Me.grpBoxContact.Controls.Add(Me.lblPro5)
        Me.grpBoxContact.Controls.Add(Me.lblPro1)
        Me.grpBoxContact.Controls.Add(Me.Label14)
        Me.grpBoxContact.Controls.Add(Me.Label13)
        Me.grpBoxContact.Controls.Add(Me.Label10)
        Me.grpBoxContact.Location = New System.Drawing.Point(6, 134)
        Me.grpBoxContact.Name = "grpBoxContact"
        Me.grpBoxContact.Size = New System.Drawing.Size(293, 108)
        Me.grpBoxContact.TabIndex = 12
        Me.grpBoxContact.TabStop = False
        Me.grpBoxContact.Text = "text"
        Me.grpBoxContact.Visible = False
        '
        'lblPro4
        '
        Me.lblPro4.AutoSize = True
        Me.lblPro4.Location = New System.Drawing.Point(101, 52)
        Me.lblPro4.Name = "lblPro4"
        Me.lblPro4.Size = New System.Drawing.Size(27, 13)
        Me.lblPro4.TabIndex = 10
        Me.lblPro4.Text = "City:"
        '
        'lblPro5
        '
        Me.lblPro5.AutoSize = True
        Me.lblPro5.Location = New System.Drawing.Point(101, 82)
        Me.lblPro5.Name = "lblPro5"
        Me.lblPro5.Size = New System.Drawing.Size(46, 13)
        Me.lblPro5.TabIndex = 9
        Me.lblPro5.Text = "Country:"
        '
        'lblPro1
        '
        Me.lblPro1.AutoSize = True
        Me.lblPro1.Location = New System.Drawing.Point(101, 22)
        Me.lblPro1.Name = "lblPro1"
        Me.lblPro1.Size = New System.Drawing.Size(48, 13)
        Me.lblPro1.TabIndex = 8
        Me.lblPro1.Text = "Address:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(7, 52)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "text"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(7, 82)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(24, 13)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "text"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 22)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(24, 13)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "text"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(343, 92)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(24, 13)
        Me.Label16.TabIndex = 9
        Me.Label16.Text = "text"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(187, 92)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(24, 13)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "text"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(187, 28)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 13)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "E-mail:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(187, 60)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(24, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "text"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 92)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(24, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "text"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 60)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "text"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 28)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(21, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "ID:"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(171, 270)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(138, 31)
        Me.btnClose.TabIndex = 20
        Me.btnClose.Text = "text"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'ProForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(672, 308)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnModPro)
        Me.Controls.Add(Me.chkBoxRecovery)
        Me.Controls.Add(Me.chkBoxContact)
        Me.Controls.Add(Me.grpBoxPro)
        Me.Name = "ProForm"
        Me.Text = "text"
        Me.grpBoxPro.ResumeLayout(False)
        Me.grpBoxPro.PerformLayout()
        CType(Me.picBoxPro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpBoxPasswd.ResumeLayout(False)
        Me.grpBoxPasswd.PerformLayout()
        Me.grpBoxContact.ResumeLayout(False)
        Me.grpBoxContact.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnModPro As System.Windows.Forms.Button
    Friend WithEvents chkBoxRecovery As System.Windows.Forms.CheckBox
    Friend WithEvents chkBoxContact As System.Windows.Forms.CheckBox
    Friend WithEvents grpBoxPro As System.Windows.Forms.GroupBox
    Friend WithEvents lblPro10 As System.Windows.Forms.Label
    Friend WithEvents lblPro8 As System.Windows.Forms.Label
    Friend WithEvents lblPro2 As System.Windows.Forms.Label
    Friend WithEvents lblPro9 As System.Windows.Forms.Label
    Friend WithEvents lblProSurname As System.Windows.Forms.Label
    Friend WithEvents lblPro3 As System.Windows.Forms.Label
    Friend WithEvents lblProName As System.Windows.Forms.Label
    Friend WithEvents lblPro0 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents picBoxPro As System.Windows.Forms.PictureBox
    Friend WithEvents grpBoxPasswd As System.Windows.Forms.GroupBox
    Friend WithEvents lblPro7 As System.Windows.Forms.Label
    Friend WithEvents lblPro6 As System.Windows.Forms.Label
    Friend WithEvents lblAwnser As System.Windows.Forms.Label
    Friend WithEvents lblQuestion As System.Windows.Forms.Label
    Friend WithEvents grpBoxContact As System.Windows.Forms.GroupBox
    Friend WithEvents lblPro4 As System.Windows.Forms.Label
    Friend WithEvents lblPro5 As System.Windows.Forms.Label
    Friend WithEvents lblPro1 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
