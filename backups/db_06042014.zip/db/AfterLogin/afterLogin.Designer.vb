﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class afterLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblSurname = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.gprBox3 = New System.Windows.Forms.GroupBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.usersGrpBox = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.UsersPic3 = New System.Windows.Forms.PictureBox()
        Me.UsersPic2 = New System.Windows.Forms.PictureBox()
        Me.UsersPic1 = New System.Windows.Forms.PictureBox()
        Me.AdminGrpBox = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.AdminPic6 = New System.Windows.Forms.PictureBox()
        Me.AdminPic5 = New System.Windows.Forms.PictureBox()
        Me.AdminPic4 = New System.Windows.Forms.PictureBox()
        Me.AdminPic3 = New System.Windows.Forms.PictureBox()
        Me.AdminPic2 = New System.Windows.Forms.PictureBox()
        Me.AdminPic1 = New System.Windows.Forms.PictureBox()
        Me.gprBox2 = New System.Windows.Forms.GroupBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.gprBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ExitPicBox = New System.Windows.Forms.PictureBox()
        Me.LogoutPicBox = New System.Windows.Forms.PictureBox()
        Me.PassPicBox = New System.Windows.Forms.PictureBox()
        Me.ProPicBox = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.gprBox3.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.usersGrpBox.SuspendLayout()
        CType(Me.UsersPic3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UsersPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UsersPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.AdminGrpBox.SuspendLayout()
        CType(Me.AdminPic6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdminPic5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdminPic4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdminPic3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdminPic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AdminPic1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gprBox2.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gprBox1.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ExitPicBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LogoutPicBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PassPicBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProPicBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel1.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.lblSurname)
        Me.Panel1.Location = New System.Drawing.Point(12, 545)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(774, 39)
        Me.Panel1.TabIndex = 10
        '
        'lblSurname
        '
        Me.lblSurname.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblSurname.AutoSize = True
        Me.lblSurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSurname.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblSurname.Location = New System.Drawing.Point(5, 4)
        Me.lblSurname.Name = "lblSurname"
        Me.lblSurname.Size = New System.Drawing.Size(0, 17)
        Me.lblSurname.TabIndex = 12
        Me.lblSurname.Tag = "lblSurname"
        Me.lblSurname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 518)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 13)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Logged in as:"
        '
        'gprBox3
        '
        Me.gprBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gprBox3.Controls.Add(Me.PictureBox4)
        Me.gprBox3.Controls.Add(Me.PictureBox6)
        Me.gprBox3.Controls.Add(Me.PictureBox5)
        Me.gprBox3.Location = New System.Drawing.Point(12, 182)
        Me.gprBox3.Name = "gprBox3"
        Me.gprBox3.Size = New System.Drawing.Size(317, 155)
        Me.gprBox3.TabIndex = 13
        Me.gprBox3.TabStop = False
        Me.gprBox3.Text = "GroupBox3"
        Me.gprBox3.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Location = New System.Drawing.Point(214, 16)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox4.TabIndex = 5
        Me.PictureBox4.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Location = New System.Drawing.Point(5, 16)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox6.TabIndex = 3
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Location = New System.Drawing.Point(110, 16)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'usersGrpBox
        '
        Me.usersGrpBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.usersGrpBox.Controls.Add(Me.Label1)
        Me.usersGrpBox.Controls.Add(Me.UsersPic3)
        Me.usersGrpBox.Controls.Add(Me.UsersPic2)
        Me.usersGrpBox.Controls.Add(Me.UsersPic1)
        Me.usersGrpBox.Location = New System.Drawing.Point(335, 182)
        Me.usersGrpBox.Name = "usersGrpBox"
        Me.usersGrpBox.Size = New System.Drawing.Size(317, 155)
        Me.usersGrpBox.TabIndex = 13
        Me.usersGrpBox.TabStop = False
        Me.usersGrpBox.Text = "Users"
        Me.usersGrpBox.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 125)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "label1"
        '
        'UsersPic3
        '
        Me.UsersPic3.Location = New System.Drawing.Point(213, 16)
        Me.UsersPic3.Name = "UsersPic3"
        Me.UsersPic3.Size = New System.Drawing.Size(100, 100)
        Me.UsersPic3.TabIndex = 2
        Me.UsersPic3.TabStop = False
        '
        'UsersPic2
        '
        Me.UsersPic2.Location = New System.Drawing.Point(109, 16)
        Me.UsersPic2.Name = "UsersPic2"
        Me.UsersPic2.Size = New System.Drawing.Size(100, 100)
        Me.UsersPic2.TabIndex = 1
        Me.UsersPic2.TabStop = False
        '
        'UsersPic1
        '
        Me.UsersPic1.Image = Global.db.My.Resources.Resources.addUser
        Me.UsersPic1.Location = New System.Drawing.Point(4, 16)
        Me.UsersPic1.Name = "UsersPic1"
        Me.UsersPic1.Size = New System.Drawing.Size(100, 100)
        Me.UsersPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.UsersPic1.TabIndex = 0
        Me.UsersPic1.TabStop = False
        '
        'AdminGrpBox
        '
        Me.AdminGrpBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AdminGrpBox.Controls.Add(Me.Label2)
        Me.AdminGrpBox.Controls.Add(Me.AdminPic6)
        Me.AdminGrpBox.Controls.Add(Me.AdminPic5)
        Me.AdminGrpBox.Controls.Add(Me.AdminPic4)
        Me.AdminGrpBox.Controls.Add(Me.AdminPic3)
        Me.AdminGrpBox.Controls.Add(Me.AdminPic2)
        Me.AdminGrpBox.Controls.Add(Me.AdminPic1)
        Me.AdminGrpBox.Location = New System.Drawing.Point(13, 354)
        Me.AdminGrpBox.Name = "AdminGrpBox"
        Me.AdminGrpBox.Size = New System.Drawing.Size(640, 155)
        Me.AdminGrpBox.TabIndex = 14
        Me.AdminGrpBox.TabStop = False
        Me.AdminGrpBox.Text = "Administrator"
        Me.AdminGrpBox.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(5, 125)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Label2"
        '
        'AdminPic6
        '
        Me.AdminPic6.Location = New System.Drawing.Point(534, 16)
        Me.AdminPic6.Name = "AdminPic6"
        Me.AdminPic6.Size = New System.Drawing.Size(100, 100)
        Me.AdminPic6.TabIndex = 8
        Me.AdminPic6.TabStop = False
        '
        'AdminPic5
        '
        Me.AdminPic5.Location = New System.Drawing.Point(429, 16)
        Me.AdminPic5.Name = "AdminPic5"
        Me.AdminPic5.Size = New System.Drawing.Size(100, 100)
        Me.AdminPic5.TabIndex = 7
        Me.AdminPic5.TabStop = False
        '
        'AdminPic4
        '
        Me.AdminPic4.Location = New System.Drawing.Point(323, 16)
        Me.AdminPic4.Name = "AdminPic4"
        Me.AdminPic4.Size = New System.Drawing.Size(100, 100)
        Me.AdminPic4.TabIndex = 6
        Me.AdminPic4.TabStop = False
        '
        'AdminPic3
        '
        Me.AdminPic3.Location = New System.Drawing.Point(218, 16)
        Me.AdminPic3.Name = "AdminPic3"
        Me.AdminPic3.Size = New System.Drawing.Size(100, 100)
        Me.AdminPic3.TabIndex = 5
        Me.AdminPic3.TabStop = False
        '
        'AdminPic2
        '
        Me.AdminPic2.Location = New System.Drawing.Point(114, 16)
        Me.AdminPic2.Name = "AdminPic2"
        Me.AdminPic2.Size = New System.Drawing.Size(100, 100)
        Me.AdminPic2.TabIndex = 4
        Me.AdminPic2.TabStop = False
        '
        'AdminPic1
        '
        Me.AdminPic1.Image = Global.db.My.Resources.Resources.userdatabase
        Me.AdminPic1.Location = New System.Drawing.Point(8, 16)
        Me.AdminPic1.Name = "AdminPic1"
        Me.AdminPic1.Size = New System.Drawing.Size(100, 100)
        Me.AdminPic1.TabIndex = 3
        Me.AdminPic1.TabStop = False
        '
        'gprBox2
        '
        Me.gprBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gprBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gprBox2.Controls.Add(Me.PictureBox7)
        Me.gprBox2.Controls.Add(Me.PictureBox8)
        Me.gprBox2.Controls.Add(Me.PictureBox9)
        Me.gprBox2.Location = New System.Drawing.Point(333, 11)
        Me.gprBox2.Name = "gprBox2"
        Me.gprBox2.Size = New System.Drawing.Size(320, 155)
        Me.gprBox2.TabIndex = 14
        Me.gprBox2.TabStop = False
        Me.gprBox2.Text = "GroupBox2"
        Me.gprBox2.Visible = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Location = New System.Drawing.Point(214, 16)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox7.TabIndex = 5
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Location = New System.Drawing.Point(5, 16)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox8.TabIndex = 3
        Me.PictureBox8.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Location = New System.Drawing.Point(110, 16)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox9.TabIndex = 4
        Me.PictureBox9.TabStop = False
        '
        'gprBox1
        '
        Me.gprBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gprBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gprBox1.Controls.Add(Me.PictureBox10)
        Me.gprBox1.Controls.Add(Me.PictureBox11)
        Me.gprBox1.Controls.Add(Me.PictureBox12)
        Me.gprBox1.Location = New System.Drawing.Point(13, 11)
        Me.gprBox1.Name = "gprBox1"
        Me.gprBox1.Size = New System.Drawing.Size(317, 155)
        Me.gprBox1.TabIndex = 14
        Me.gprBox1.TabStop = False
        Me.gprBox1.Text = "GroupBox1"
        Me.gprBox1.Visible = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Location = New System.Drawing.Point(214, 16)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox10.TabIndex = 5
        Me.PictureBox10.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.Location = New System.Drawing.Point(5, 16)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox11.TabIndex = 3
        Me.PictureBox11.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.Location = New System.Drawing.Point(110, 16)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox12.TabIndex = 4
        Me.PictureBox12.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(701, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 17)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "label3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(669, 246)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 17)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "label4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(697, 367)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 17)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "label5"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(710, 490)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 17)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "label6"
        '
        'ExitPicBox
        '
        Me.ExitPicBox.Image = Global.db.My.Resources.Resources.exit_salida
        Me.ExitPicBox.Location = New System.Drawing.Point(681, 397)
        Me.ExitPicBox.Name = "ExitPicBox"
        Me.ExitPicBox.Size = New System.Drawing.Size(90, 90)
        Me.ExitPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ExitPicBox.TabIndex = 17
        Me.ExitPicBox.TabStop = False
        '
        'LogoutPicBox
        '
        Me.LogoutPicBox.Image = Global.db.My.Resources.Resources.logout
        Me.LogoutPicBox.Location = New System.Drawing.Point(681, 275)
        Me.LogoutPicBox.Name = "LogoutPicBox"
        Me.LogoutPicBox.Size = New System.Drawing.Size(90, 90)
        Me.LogoutPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.LogoutPicBox.TabIndex = 16
        Me.LogoutPicBox.TabStop = False
        '
        'PassPicBox
        '
        Me.PassPicBox.Image = Global.db.My.Resources.Resources.chgpassword
        Me.PassPicBox.Location = New System.Drawing.Point(681, 153)
        Me.PassPicBox.Name = "PassPicBox"
        Me.PassPicBox.Size = New System.Drawing.Size(90, 90)
        Me.PassPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PassPicBox.TabIndex = 15
        Me.PassPicBox.TabStop = False
        '
        'ProPicBox
        '
        Me.ProPicBox.Image = Global.db.My.Resources.Resources.profile
        Me.ProPicBox.Location = New System.Drawing.Point(681, 31)
        Me.ProPicBox.Name = "ProPicBox"
        Me.ProPicBox.Size = New System.Drawing.Size(90, 90)
        Me.ProPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ProPicBox.TabIndex = 6
        Me.ProPicBox.TabStop = False
        '
        'afterLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(793, 587)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ExitPicBox)
        Me.Controls.Add(Me.LogoutPicBox)
        Me.Controls.Add(Me.PassPicBox)
        Me.Controls.Add(Me.AdminGrpBox)
        Me.Controls.Add(Me.ProPicBox)
        Me.Controls.Add(Me.gprBox1)
        Me.Controls.Add(Me.gprBox2)
        Me.Controls.Add(Me.gprBox3)
        Me.Controls.Add(Me.usersGrpBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "afterLogin"
        Me.Text = "Menu"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.gprBox3.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.usersGrpBox.ResumeLayout(False)
        Me.usersGrpBox.PerformLayout()
        CType(Me.UsersPic3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UsersPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UsersPic1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.AdminGrpBox.ResumeLayout(False)
        Me.AdminGrpBox.PerformLayout()
        CType(Me.AdminPic6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdminPic5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdminPic4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdminPic3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdminPic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AdminPic1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gprBox2.ResumeLayout(False)
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gprBox1.ResumeLayout(False)
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ExitPicBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LogoutPicBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PassPicBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProPicBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LevelDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblSurname As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents gprBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents usersGrpBox As System.Windows.Forms.GroupBox
    Friend WithEvents AdminGrpBox As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents UsersPic3 As System.Windows.Forms.PictureBox
    Friend WithEvents UsersPic2 As System.Windows.Forms.PictureBox
    Friend WithEvents UsersPic1 As System.Windows.Forms.PictureBox
    Friend WithEvents gprBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents gprBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents AdminPic6 As System.Windows.Forms.PictureBox
    Friend WithEvents AdminPic5 As System.Windows.Forms.PictureBox
    Friend WithEvents AdminPic4 As System.Windows.Forms.PictureBox
    Friend WithEvents AdminPic3 As System.Windows.Forms.PictureBox
    Friend WithEvents AdminPic2 As System.Windows.Forms.PictureBox
    Friend WithEvents AdminPic1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ProPicBox As System.Windows.Forms.PictureBox
    Friend WithEvents PassPicBox As System.Windows.Forms.PictureBox
    Friend WithEvents LogoutPicBox As System.Windows.Forms.PictureBox
    Friend WithEvents ExitPicBox As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
