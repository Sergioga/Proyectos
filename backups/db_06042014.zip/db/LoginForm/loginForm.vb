﻿Public Class loginForm

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = My.Resources.strings_en.userName
        Label2.Text = My.Resources.strings_en.pass
        btnLogin.Text = My.Resources.strings_en.btnLogInStr
        connect()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim login As String
        Dim passwd As String
        login = txtUser.Text
        passwd = txtPass.Text
        loginfunc(login, passwd)
    End Sub

    Private Sub txtPass_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPass.KeyPress
        If e.KeyChar = Convert.ToChar(Keys.Enter) Then
            Dim login As String
            Dim passwd As String
            login = txtUser.Text
            passwd = txtPass.Text
            loginfunc(login, passwd)
        End If
    End Sub

End Class
