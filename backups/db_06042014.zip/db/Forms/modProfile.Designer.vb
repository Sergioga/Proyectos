﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class modProfile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.lblUserId = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblSurname = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lvlMobPhone = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblCity = New System.Windows.Forms.Label()
        Me.lblCountry = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblSecretA = New System.Windows.Forms.Label()
        Me.dateDateOB = New System.Windows.Forms.DateTimePicker()
        Me.lblDateOB = New System.Windows.Forms.Label()
        Me.txtPro0 = New System.Windows.Forms.TextBox()
        Me.txtPro1 = New System.Windows.Forms.TextBox()
        Me.txtPro4 = New System.Windows.Forms.TextBox()
        Me.txtPro3 = New System.Windows.Forms.TextBox()
        Me.txtPro2 = New System.Windows.Forms.TextBox()
        Me.txtPro6 = New System.Windows.Forms.TextBox()
        Me.txtPro7 = New System.Windows.Forms.TextBox()
        Me.txtPro5 = New System.Windows.Forms.TextBox()
        Me.txtPro8 = New System.Windows.Forms.TextBox()
        Me.lblPro8 = New System.Windows.Forms.Label()
        Me.lblPro2 = New System.Windows.Forms.Label()
        Me.lblPro9 = New System.Windows.Forms.Label()
        Me.lblProSurname = New System.Windows.Forms.Label()
        Me.lblPro3 = New System.Windows.Forms.Label()
        Me.lblProName = New System.Windows.Forms.Label()
        Me.lblPro0 = New System.Windows.Forms.Label()
        Me.lblPro7 = New System.Windows.Forms.Label()
        Me.lblPro6 = New System.Windows.Forms.Label()
        Me.lblPro4 = New System.Windows.Forms.Label()
        Me.lblPro5 = New System.Windows.Forms.Label()
        Me.lblPro1 = New System.Windows.Forms.Label()
        Me.ComboSecret = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblNew = New System.Windows.Forms.Label()
        Me.lblActu = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(41, 492)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(133, 23)
        Me.btnBack.TabIndex = 12
        Me.btnBack.Text = "text"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(271, 492)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(133, 23)
        Me.btnSubmit.TabIndex = 11
        Me.btnSubmit.Text = "text"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'lblUserId
        '
        Me.lblUserId.AutoSize = True
        Me.lblUserId.Location = New System.Drawing.Point(46, 50)
        Me.lblUserId.Name = "lblUserId"
        Me.lblUserId.Size = New System.Drawing.Size(21, 13)
        Me.lblUserId.TabIndex = 2
        Me.lblUserId.Text = "ID:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(46, 83)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(29, 13)
        Me.lblName.TabIndex = 3
        Me.lblName.Text = "label"
        '
        'lblSurname
        '
        Me.lblSurname.AutoSize = True
        Me.lblSurname.Location = New System.Drawing.Point(46, 116)
        Me.lblSurname.Name = "lblSurname"
        Me.lblSurname.Size = New System.Drawing.Size(29, 13)
        Me.lblSurname.TabIndex = 4
        Me.lblSurname.Text = "label"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(46, 281)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(29, 13)
        Me.lblAddress.TabIndex = 5
        Me.lblAddress.Text = "label"
        '
        'lvlMobPhone
        '
        Me.lvlMobPhone.AutoSize = True
        Me.lvlMobPhone.Location = New System.Drawing.Point(46, 215)
        Me.lvlMobPhone.Name = "lvlMobPhone"
        Me.lvlMobPhone.Size = New System.Drawing.Size(29, 13)
        Me.lvlMobPhone.TabIndex = 6
        Me.lvlMobPhone.Text = "label"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(46, 248)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(29, 13)
        Me.lblPhone.TabIndex = 7
        Me.lblPhone.Text = "label"
        '
        'lblCity
        '
        Me.lblCity.AutoSize = True
        Me.lblCity.Location = New System.Drawing.Point(46, 314)
        Me.lblCity.Name = "lblCity"
        Me.lblCity.Size = New System.Drawing.Size(29, 13)
        Me.lblCity.TabIndex = 8
        Me.lblCity.Text = "label"
        '
        'lblCountry
        '
        Me.lblCountry.AutoSize = True
        Me.lblCountry.Location = New System.Drawing.Point(46, 347)
        Me.lblCountry.Name = "lblCountry"
        Me.lblCountry.Size = New System.Drawing.Size(29, 13)
        Me.lblCountry.TabIndex = 9
        Me.lblCountry.Text = "label"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(46, 182)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(38, 13)
        Me.lblEmail.TabIndex = 10
        Me.lblEmail.Text = "E-mail:"
        '
        'lblSecretA
        '
        Me.lblSecretA.AutoSize = True
        Me.lblSecretA.Location = New System.Drawing.Point(5, 463)
        Me.lblSecretA.Name = "lblSecretA"
        Me.lblSecretA.Size = New System.Drawing.Size(29, 13)
        Me.lblSecretA.TabIndex = 11
        Me.lblSecretA.Text = "label"
        '
        'dateDateOB
        '
        Me.dateDateOB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dateDateOB.Location = New System.Drawing.Point(159, 145)
        Me.dateDateOB.Name = "dateDateOB"
        Me.dateDateOB.ShowCheckBox = True
        Me.dateDateOB.Size = New System.Drawing.Size(121, 20)
        Me.dateDateOB.TabIndex = 2
        Me.dateDateOB.Value = New Date(2010, 4, 1, 0, 0, 0, 0)
        '
        'lblDateOB
        '
        Me.lblDateOB.AutoSize = True
        Me.lblDateOB.Location = New System.Drawing.Point(46, 149)
        Me.lblDateOB.Name = "lblDateOB"
        Me.lblDateOB.Size = New System.Drawing.Size(29, 13)
        Me.lblDateOB.TabIndex = 13
        Me.lblDateOB.Text = "label"
        '
        'txtPro0
        '
        Me.txtPro0.Location = New System.Drawing.Point(170, 81)
        Me.txtPro0.Name = "txtPro0"
        Me.txtPro0.Size = New System.Drawing.Size(100, 20)
        Me.txtPro0.TabIndex = 0
        '
        'txtPro1
        '
        Me.txtPro1.Location = New System.Drawing.Point(170, 113)
        Me.txtPro1.Name = "txtPro1"
        Me.txtPro1.Size = New System.Drawing.Size(100, 20)
        Me.txtPro1.TabIndex = 1
        '
        'txtPro4
        '
        Me.txtPro4.Location = New System.Drawing.Point(170, 245)
        Me.txtPro4.Name = "txtPro4"
        Me.txtPro4.Size = New System.Drawing.Size(100, 20)
        Me.txtPro4.TabIndex = 5
        '
        'txtPro3
        '
        Me.txtPro3.Location = New System.Drawing.Point(170, 212)
        Me.txtPro3.Name = "txtPro3"
        Me.txtPro3.Size = New System.Drawing.Size(100, 20)
        Me.txtPro3.TabIndex = 4
        '
        'txtPro2
        '
        Me.txtPro2.Location = New System.Drawing.Point(170, 182)
        Me.txtPro2.Name = "txtPro2"
        Me.txtPro2.Size = New System.Drawing.Size(100, 20)
        Me.txtPro2.TabIndex = 3
        '
        'txtPro6
        '
        Me.txtPro6.Location = New System.Drawing.Point(170, 311)
        Me.txtPro6.Name = "txtPro6"
        Me.txtPro6.Size = New System.Drawing.Size(100, 20)
        Me.txtPro6.TabIndex = 7
        '
        'txtPro7
        '
        Me.txtPro7.Location = New System.Drawing.Point(170, 344)
        Me.txtPro7.Name = "txtPro7"
        Me.txtPro7.Size = New System.Drawing.Size(100, 20)
        Me.txtPro7.TabIndex = 8
        '
        'txtPro5
        '
        Me.txtPro5.Location = New System.Drawing.Point(170, 274)
        Me.txtPro5.Name = "txtPro5"
        Me.txtPro5.Size = New System.Drawing.Size(100, 20)
        Me.txtPro5.TabIndex = 6
        '
        'txtPro8
        '
        Me.txtPro8.Location = New System.Drawing.Point(116, 459)
        Me.txtPro8.Name = "txtPro8"
        Me.txtPro8.Size = New System.Drawing.Size(100, 20)
        Me.txtPro8.TabIndex = 10
        '
        'lblPro8
        '
        Me.lblPro8.AutoSize = True
        Me.lblPro8.Location = New System.Drawing.Point(303, 149)
        Me.lblPro8.Name = "lblPro8"
        Me.lblPro8.Size = New System.Drawing.Size(69, 13)
        Me.lblPro8.TabIndex = 35
        Me.lblPro8.Text = "Date of Birth:"
        '
        'lblPro2
        '
        Me.lblPro2.AutoSize = True
        Me.lblPro2.Location = New System.Drawing.Point(303, 215)
        Me.lblPro2.Name = "lblPro2"
        Me.lblPro2.Size = New System.Drawing.Size(41, 13)
        Me.lblPro2.TabIndex = 34
        Me.lblPro2.Text = "Mobile:"
        '
        'lblPro9
        '
        Me.lblPro9.AutoSize = True
        Me.lblPro9.Location = New System.Drawing.Point(303, 182)
        Me.lblPro9.Name = "lblPro9"
        Me.lblPro9.Size = New System.Drawing.Size(38, 13)
        Me.lblPro9.TabIndex = 33
        Me.lblPro9.Text = "E-mail:"
        '
        'lblProSurname
        '
        Me.lblProSurname.AutoSize = True
        Me.lblProSurname.Location = New System.Drawing.Point(303, 116)
        Me.lblProSurname.Name = "lblProSurname"
        Me.lblProSurname.Size = New System.Drawing.Size(52, 13)
        Me.lblProSurname.TabIndex = 32
        Me.lblProSurname.Text = "Surname:"
        '
        'lblPro3
        '
        Me.lblPro3.AutoSize = True
        Me.lblPro3.Location = New System.Drawing.Point(303, 248)
        Me.lblPro3.Name = "lblPro3"
        Me.lblPro3.Size = New System.Drawing.Size(81, 13)
        Me.lblPro3.TabIndex = 31
        Me.lblPro3.Text = "Phone Number:"
        '
        'lblProName
        '
        Me.lblProName.AutoSize = True
        Me.lblProName.Location = New System.Drawing.Point(303, 84)
        Me.lblProName.Name = "lblProName"
        Me.lblProName.Size = New System.Drawing.Size(38, 13)
        Me.lblProName.TabIndex = 30
        Me.lblProName.Text = "Name:"
        '
        'lblPro0
        '
        Me.lblPro0.AutoSize = True
        Me.lblPro0.Location = New System.Drawing.Point(303, 52)
        Me.lblPro0.Name = "lblPro0"
        Me.lblPro0.Size = New System.Drawing.Size(46, 13)
        Me.lblPro0.TabIndex = 29
        Me.lblPro0.Text = "User ID:"
        '
        'lblPro7
        '
        Me.lblPro7.AutoSize = True
        Me.lblPro7.Location = New System.Drawing.Point(303, 459)
        Me.lblPro7.Name = "lblPro7"
        Me.lblPro7.Size = New System.Drawing.Size(79, 13)
        Me.lblPro7.TabIndex = 28
        Me.lblPro7.Text = "Secret Awnser:"
        '
        'lblPro6
        '
        Me.lblPro6.AutoEllipsis = True
        Me.lblPro6.AutoSize = True
        Me.lblPro6.Location = New System.Drawing.Point(113, 427)
        Me.lblPro6.Name = "lblPro6"
        Me.lblPro6.Size = New System.Drawing.Size(86, 13)
        Me.lblPro6.TabIndex = 27
        Me.lblPro6.Text = "Secret Question:"
        '
        'lblPro4
        '
        Me.lblPro4.AutoSize = True
        Me.lblPro4.Location = New System.Drawing.Point(303, 314)
        Me.lblPro4.Name = "lblPro4"
        Me.lblPro4.Size = New System.Drawing.Size(27, 13)
        Me.lblPro4.TabIndex = 26
        Me.lblPro4.Text = "City:"
        '
        'lblPro5
        '
        Me.lblPro5.AutoSize = True
        Me.lblPro5.Location = New System.Drawing.Point(303, 347)
        Me.lblPro5.Name = "lblPro5"
        Me.lblPro5.Size = New System.Drawing.Size(46, 13)
        Me.lblPro5.TabIndex = 25
        Me.lblPro5.Text = "Country:"
        '
        'lblPro1
        '
        Me.lblPro1.AutoSize = True
        Me.lblPro1.Location = New System.Drawing.Point(303, 281)
        Me.lblPro1.Name = "lblPro1"
        Me.lblPro1.Size = New System.Drawing.Size(48, 13)
        Me.lblPro1.TabIndex = 24
        Me.lblPro1.Text = "Address:"
        '
        'ComboSecret
        '
        Me.ComboSecret.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboSecret.DropDownWidth = 280
        Me.ComboSecret.FormattingEnabled = True
        Me.ComboSecret.Location = New System.Drawing.Point(109, 389)
        Me.ComboSecret.Name = "ComboSecret"
        Me.ComboSecret.Size = New System.Drawing.Size(304, 21)
        Me.ComboSecret.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 393)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "label"
        '
        'lblNew
        '
        Me.lblNew.AutoSize = True
        Me.lblNew.Location = New System.Drawing.Point(173, 11)
        Me.lblNew.Name = "lblNew"
        Me.lblNew.Size = New System.Drawing.Size(29, 13)
        Me.lblNew.TabIndex = 38
        Me.lblNew.Text = "label"
        '
        'lblActu
        '
        Me.lblActu.AutoSize = True
        Me.lblActu.Location = New System.Drawing.Point(303, 11)
        Me.lblActu.Name = "lblActu"
        Me.lblActu.Size = New System.Drawing.Size(29, 13)
        Me.lblActu.TabIndex = 39
        Me.lblActu.Text = "label"
        '
        'modProfile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(473, 558)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblActu)
        Me.Controls.Add(Me.lblNew)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboSecret)
        Me.Controls.Add(Me.lblPro8)
        Me.Controls.Add(Me.lblPro2)
        Me.Controls.Add(Me.lblPro9)
        Me.Controls.Add(Me.lblProSurname)
        Me.Controls.Add(Me.lblPro3)
        Me.Controls.Add(Me.lblProName)
        Me.Controls.Add(Me.lblPro0)
        Me.Controls.Add(Me.lblPro7)
        Me.Controls.Add(Me.lblPro6)
        Me.Controls.Add(Me.lblPro4)
        Me.Controls.Add(Me.lblPro5)
        Me.Controls.Add(Me.lblPro1)
        Me.Controls.Add(Me.txtPro8)
        Me.Controls.Add(Me.txtPro6)
        Me.Controls.Add(Me.txtPro7)
        Me.Controls.Add(Me.txtPro5)
        Me.Controls.Add(Me.txtPro4)
        Me.Controls.Add(Me.txtPro3)
        Me.Controls.Add(Me.txtPro2)
        Me.Controls.Add(Me.txtPro1)
        Me.Controls.Add(Me.txtPro0)
        Me.Controls.Add(Me.lblDateOB)
        Me.Controls.Add(Me.dateDateOB)
        Me.Controls.Add(Me.lblSecretA)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblCountry)
        Me.Controls.Add(Me.lblCity)
        Me.Controls.Add(Me.lblPhone)
        Me.Controls.Add(Me.lvlMobPhone)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblSurname)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblUserId)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.btnBack)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximumSize = New System.Drawing.Size(489, 596)
        Me.MinimumSize = New System.Drawing.Size(489, 596)
        Me.Name = "modProfile"
        Me.Text = "Modify Profile"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents lblUserId As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblSurname As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lvlMobPhone As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblCity As System.Windows.Forms.Label
    Friend WithEvents lblCountry As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents lblSecretA As System.Windows.Forms.Label
    Friend WithEvents dateDateOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDateOB As System.Windows.Forms.Label
    Friend WithEvents txtPro0 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro1 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro4 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro3 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro6 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro7 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro5 As System.Windows.Forms.TextBox
    Friend WithEvents txtPro8 As System.Windows.Forms.TextBox
    Friend WithEvents lblPro8 As System.Windows.Forms.Label
    Friend WithEvents lblPro2 As System.Windows.Forms.Label
    Friend WithEvents lblPro9 As System.Windows.Forms.Label
    Friend WithEvents lblProSurname As System.Windows.Forms.Label
    Friend WithEvents lblPro3 As System.Windows.Forms.Label
    Friend WithEvents lblProName As System.Windows.Forms.Label
    Friend WithEvents lblPro0 As System.Windows.Forms.Label
    Friend WithEvents lblPro7 As System.Windows.Forms.Label
    Friend WithEvents lblPro6 As System.Windows.Forms.Label
    Friend WithEvents lblPro4 As System.Windows.Forms.Label
    Friend WithEvents lblPro5 As System.Windows.Forms.Label
    Friend WithEvents lblPro1 As System.Windows.Forms.Label
    Friend WithEvents ComboSecret As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblNew As System.Windows.Forms.Label
    Friend WithEvents lblActu As System.Windows.Forms.Label
End Class
